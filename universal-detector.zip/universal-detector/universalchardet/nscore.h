#include "prtypes.h"

typedef PRUint32 nsresult;

#define nsnull 0
#define NS_COM

#include "nsError.h"
