//
//  main.m
//  Part of the SMDoubleSlider framework project.
//
#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
