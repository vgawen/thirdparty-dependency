#if __OBJC__
    #import <Cocoa/Cocoa.h>
#endif