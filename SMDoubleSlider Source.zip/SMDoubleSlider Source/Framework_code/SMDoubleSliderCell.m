//
//  SMDoubleSliderCell.m
//
//SMDoubleSlider Copyright (c) 2003-2010, Snowmint Creative Solutions LLC http://www.snowmintcs.com/
//All rights reserved.
//
//Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
//• Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
//• Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
//• Neither the name of Snowmint Creative Solutions LLC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
//
//THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#import <AppKit/AppKit.h>

#import "SMDoubleSliderCell.h"
#import "SMDoubleSlider.h"

@interface SMDoubleSliderCell(_sm_Private)
	// A private method to calculate the rectangle of the low knob.
	- (NSRect)_sm_loKnobRect;
@end

@interface SMDoubleSliderCell ()
{
    NSRect _currentKnobRect;
    NSRect _barRect;
    BOOL _flipped;
}

@end

@implementation SMDoubleSliderCell

- (id)initWithCoder:(NSCoder *)aDecoder
{
    BOOL	tempBool;

    self = [ super initWithCoder:aDecoder ];

    if ( nil != self )
    {
		if ( [ aDecoder allowsKeyedCoding ] )
		{
			_sm_loValue = [ aDecoder decodeDoubleForKey:@"loValue" ];
            _sm_hiValue = [ aDecoder decodeDoubleForKey:@"hiValue" ];
			tempBool = [ aDecoder decodeBoolForKey:@"lockedSliders" ];
		}
		else
		{
			[ aDecoder decodeValueOfObjCType:@encode(double) at:&_sm_loValue ];
            [ aDecoder decodeValueOfObjCType:@encode(double) at:&_sm_hiValue ];
			[ aDecoder decodeValueOfObjCType:@encode(BOOL) at:&tempBool ];
		}

		_sm_flags.lockedSliders = tempBool;

		// Make sure our value is between min and max.
		if ( [ self minValue ] > _sm_loValue )
			_sm_loValue = [ self minValue ];
		if ( [ self maxValue ] < _sm_loValue )
			_sm_loValue = [ self maxValue ];
        
        if ( [self minValue] > _sm_hiValue )
            _sm_hiValue = [ self minValue ];
        if ( [self maxValue] < _sm_hiValue )
            _sm_hiValue = [ self maxValue ];
        
        if (_sm_loValue > _sm_hiValue)
            _sm_loValue = _sm_hiValue;

        _sm_hiValue = [self maxValue];
        _sm_flags.isTrackingLoKnob = NO;
        _sm_flags.isTrackingHiKnob = NO;
        
        NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"RangeSliderBundle" ofType:@"bundle"];
        NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
//        [bundle load];
        NSString *path = [bundle pathForImageResource:@"edit_trimknob_normal.png"];
        _knobImage = [[NSImage alloc] initWithContentsOfFile: path];
        path = [bundle pathForImageResource:@"edit_trimleft_normal.png"];
        _loKnobImage = [[NSImage alloc] initWithContentsOfFile: path];
        path = [bundle pathForImageResource:@"edit_trimright_normal.png"];
        _hiKnobImage = [[NSImage alloc] initWithContentsOfFile: path];
        path = [bundle pathForImageResource:@"edit_trim_rightedge.png"];
        _barRightEdgeImage = [[NSImage alloc] initWithContentsOfFile: path];
        path = [bundle pathForImageResource:@"edit_trim_leftedge.png"];
        _barLeftEdgeImage = [[NSImage alloc] initWithContentsOfFile: path];
        path = [bundle pathForImageResource:@"edit_trim_barfill.png"];
        _barFillImage = [[NSImage alloc] initWithContentsOfFile: path];
        path = [bundle pathForImageResource:@"edit_trim_barrangefill.png"];
        _barFillRangeImage = [[NSImage alloc] initWithContentsOfFile: path];
    }
	
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    BOOL	tempBool;

    [ super encodeWithCoder:aCoder ];

	tempBool = _sm_flags.lockedSliders;

	if ( [ aCoder allowsKeyedCoding ] )
	{
		[ aCoder encodeDouble:_sm_loValue forKey:@"loValue" ];
        [ aCoder encodeDouble:_sm_hiValue forKey:@"hiValue" ];
		[ aCoder encodeBool:tempBool forKey:@"lockedSliders" ];
	}
	else
	{
		[ aCoder encodeValueOfObjCType:@encode(double) at:&_sm_loValue ];
        [ aCoder encodeValueOfObjCType:@encode(double) at:&_sm_hiValue ];
		[ aCoder encodeValueOfObjCType:@encode(BOOL) at:&tempBool ];
	}
}

- (id)copyWithZone:(NSZone *)zone
{
    SMDoubleSliderCell *copy;

    copy = [ super copyWithZone:zone ];

    [ copy setDoubleLoValue:[ self doubleLoValue ] ];
    [ copy setLockedSliders:[ self lockedSliders ] ];

    return copy;
}

- (void)setMinValue:(double)aDouble
{
    // Make sure we check both lo and hi values.
    if ( [ self doubleLoValue ] < aDouble )
        [ self setDoubleLoValue:aDouble ];
    if ( [ self doubleHiValue ] < aDouble )
        [ self setDoubleHiValue:aDouble ];

    [ super setMinValue:aDouble ];
}

- (void)setMaxValue:(double)aDouble
{
    // Make sure we check both lo and hi values.
    if ( [ self doubleLoValue ] > aDouble )
        [ self setDoubleLoValue:aDouble ];
    if ( [ self doubleHiValue ] > aDouble )
        [ self setDoubleHiValue:aDouble ];

    [ super setMaxValue:aDouble ];
}

/*- (void)setShowsFirstResponder:(BOOL)inValue
{
    NSLog( @"%x -setShowsFirstResponder:%d (was %d) dir=%d", self, inValue, _cFlags.showsFirstResponder,
                [ [ [ self controlView ] window ] keyViewSelectionDirection ] );
    if ( inValue && !_cFlags.showsFirstResponder &&
                [ [ [ self controlView ] window ] keyViewSelectionDirection ] != NSDirectSelection )
    {
        [ self setTrackingLoKnob:( [ [ [ self controlView ] window ] keyViewSelectionDirection ] ==
                    NSSelectingNext ) ];
    }

    [ super setShowsFirstResponder:inValue ];
}*/

/*- (BOOL)acceptsFirstResponder
{
    BOOL		result;

    NSLog( @"%x -acceptsFirstResponder called", self );
    result = [ super acceptsFirstResponder ];
    if ( result && [ [ [ self controlView ] window ] keyViewSelectionDirection ] != NSDirectSelection )
        [ self setTrackingLoKnob:( [ [ [ self controlView ] window ] keyViewSelectionDirection ] == NSSelectingNext ) ];

    return result;
}*/

- (void)drawKnob
{
    NSRect	loKnobRect, hiKnobRect, indicatorKnobRect;
    double	saveValue = self.doubleValue;
//    BOOL	savePressed = _scFlags.isPressed;
    
    //---------------------Interesting-bug----------------------
    //  Sometimes slider may have some bugs when you
    //  just click on it and hold the mouse down.
    //  To prevent this I call this method once again
    //  right here.
    //  !!!- If you know other way how to prevent it
    //  please tell me about it -!!!
//    [self drawBarInside:_barRect flipped:_flipped];
    //---------------------Interesting-bug----------------------

    // Draw the lower knob first.
    if ( !_sm_flags.isTrackingLoKnob /*!_sm_flags.mouseTrackingSwapped*/ )
        // If we're tracking the lo knob with the mouse, _value already has the lo knob value.
        // Otherwise, we need to stuff the lo value into _value to calculate correctly.
        self.doubleValue = _sm_loValue;

    // Figure out the focus ring style and pressed state of the low knob.
//    _sm_flags.removeFocusRingStyle = ( _cFlags.showsFirstResponder && ![ self trackingLoKnob ] );
//    _scFlags.isPressed = ( savePressed && [ self trackingLoKnob ] );

    loKnobRect = [self _sm_loKnobRect];
    [ self drawKnob:loKnobRect withImage:_loKnobImage];
    
    self.doubleValue = saveValue;
    
    
    // Draw the higher knob
    if ( !_sm_flags.isTrackingHiKnob )
        self.doubleValue = _sm_hiValue;
//    _sm_flags.removeFocusRingStyle = (_cFlags.showsFirstResponder && ![self trackingHiKnob] );
//    _scFlags.isPressed = ( savePressed && [ self trackingHiKnob] );
    
    hiKnobRect = [self _sm_hiKnobRect];
    [ self drawKnob:hiKnobRect withImage:_hiKnobImage];
    

    // Now, draw the upper knob in the correct state.
//    if ( _sm_flags.mouseTrackingSwapped )
//        // If we're tracking the lo knob, the hi knob value is saved in _sm_saveValue.
//        _value = _sm_saveValue;
//    else
        // Restore to proper position of hi knob.
    self.doubleValue = saveValue;

    // Figure out the focus ring style and pressed state of the high knob.
//    _sm_flags.removeFocusRingStyle = ( _cFlags.showsFirstResponder && ([ self trackingLoKnob ] || [ self trackingHiKnob ]) );
//    _scFlags.isPressed = ( savePressed && ![ self trackingLoKnob ] && ![ self trackingHiKnob ] );
    
    indicatorKnobRect = [self _sm_indicatorKnobRect];
    [self drawKnob:indicatorKnobRect withImage:_knobImage];
//    [ super drawKnob ];

    // Reset to whatever values we had at the beginning of this method.
    self.doubleValue = saveValue;
//    _scFlags.isPressed = savePressed;
    _sm_flags.removeFocusRingStyle = NO;
}

- (void)drawKnob:(NSRect)inRect withImage:(NSImage *)image
{
	unsigned int	t_focus_ring_type;

    if ( _sm_flags.removeFocusRingStyle )
	{
		if ( [ self respondsToSelector:@selector(focusRingType) ] )
		{
			t_focus_ring_type = [ self focusRingType ];
			[ self setFocusRingType:NSFocusRingTypeNone ];
		}

		// This seems backwards, but the problem is that NSSliderCell has set the focus ring style,
		// and we want to remove that style.  So, we pop the graphics state off the stack.
        [ [ NSGraphicsContext currentContext ] restoreGraphicsState ];
	}

    if (image == nil)
        [ super drawKnob:inRect ];
    else
    {
//        [image compositeToPoint:NSMakePoint(inRect.origin.x, inRect.origin.y + image.size.height)
//                           operation:NSCompositeSourceOver];
    
//        [image drawAtPoint:NSMakePoint(inRect.origin.x, inRect.origin.y) fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:1.0];
        [image drawInRect:inRect fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:1.0 respectFlipped:YES hints:nil];
    }

    if ( _sm_flags.removeFocusRingStyle )
    {
		if ( [ self respondsToSelector:@selector(focusRingType) ] )
		{
			[ self setFocusRingType:t_focus_ring_type ];
		}

		// Reset the graphics context stack and add the correct focus ring style back in.
		[ [ NSGraphicsContext currentContext ] saveGraphicsState ];
		NSSetFocusRingStyle( NSFocusRingAbove );
    }
}


- (void)drawBarInside:(NSRect)cellFrame flipped:(BOOL)flipped {

    
    //---------------------Interesting-bug----------------------
    //   Again we save this to prevent the same bug
    //   I've wrote inside the drawKnob: method
    _barRect = cellFrame;
    _flipped = flipped;
    //---------------------Interesting-bug----------------------
    
//    NSRect beforeKnobRect = [self createBeforeKnobRect];
//    NSRect afterKnobRect = [self createAfterKnobRect];
    
    //  Sometimes you can see the ages off you bar
    //  even if your knob is at the end or
    //  at the beginning of it. It's about one pixel
    //  but this help to hide that edges
//    if( self.minValue != self.doubleValue ) {
//        NSDrawThreePartImage(beforeKnobRect, _barLeftAgeImage, _barFillBeforeKnobImage, _barFillBeforeKnobImage,
//                             NO, NSCompositeSourceOver, 1.0, flipped);
//    }
    
//    if( self.maxValue != self.doubleValue ) {
//        NSDrawThreePartImage(afterKnobRect, _barFillImage, _barFillImage, _barRightAgeImage,
//                             NO, NSCompositeSourceOver, 1.0, flipped);
//    }
    
//    cellFrame.origin.x = _sm_loValue * cellFrame.size.width / (_maxValue - _minValue);
//    cellFrame.size.width = cellFrame.size.width - cellFrame.origin.x;
    if (_barFillImage == nil || _barFillRangeImage == nil)
    {
        [super drawBarInside:cellFrame flipped:flipped];
        return;
    }
    cellFrame.origin.y = cellFrame.origin.y - (_barFillImage.size.height - cellFrame.size.height)/2;
    cellFrame.size.height = _barFillImage.size.height;
    NSDrawThreePartImage(cellFrame, _barLeftEdgeImage, _barFillImage, _barRightEdgeImage, NO, NSCompositeSourceOver, 1.0, flipped);
    NSRect loKnobRect = [self _sm_loKnobRect];
    NSRect hiKnobRect = [self _sm_hiKnobRect];
//    cellFrame.size.width = loKnobRect.origin.x + loKnobRect.size.width - cellFrame.origin.x;
//    NSDrawThreePartImage(cellFrame, _barLeftEdgeImage, _barFillImage, _barFillImage, NO, NSCompositeSourceOver, 1.0, flipped);

    
    cellFrame.origin.x = loKnobRect.origin.x + loKnobRect.size.width;
    cellFrame.size.width = hiKnobRect.origin.x - cellFrame.origin.x;
    NSDrawThreePartImage(cellFrame, _barFillRangeImage, _barFillRangeImage, _barFillRangeImage, NO, NSCompositeSourceOver, 1.0, flipped);
}


// Mouse tracking doesn't use the accessor methods for the value.
// That means, we need to do some hocus pocus here to make it work right.
- (BOOL)startTrackingAt:(NSPoint)startPoint inView:(NSView *)controlView
{
    
    int result;
    result = [ super startTrackingAt:startPoint inView:controlView ];
    
    NSRect		loKnobRect;
    loKnobRect = [ self _sm_loKnobRect ];
    
    // Determine if we're tracking the low knob or not.
    [self setTrackingKnob:startPoint inView:controlView];
    

    // Make sure that the entire lo knob gets erased if it's moved the first time.
    if ( [ self trackingLoKnob ] )
        [ controlView setNeedsDisplayInRect:loKnobRect ];

    // Save the value of the indicator knob.
    _sm_saveValue = self.doubleValue;

    // The _value variable (NSSliderCell implementation without accessor method calls) is used to track
    // any knob with the mouse.
    // However, if the user is tracking the lo knob, we need to switch in our lo value for the knob.
    _sm_flags.mouseTrackingSwapped = ([ self trackingLoKnob ] || [self trackingHiKnob]);
    if ( _sm_flags.isTrackingLoKnob )
        self.doubleValue = _sm_loValue;
    if (_sm_flags.isTrackingHiKnob)
        self.doubleValue = _sm_hiValue;

//    return [ super startTrackingAt:startPoint inView:controlView ];
    return result;
}

- (BOOL)continueTracking:(NSPoint)lastPoint at:(NSPoint)currentPoint inView:(NSView *)controlView
{
    BOOL	result;

    result = [ super continueTracking:lastPoint at:currentPoint inView:controlView ];

    // NOTE: This doesn't seem to be a problem for continuous sliders, although I did think about that.
    // If the super implementation of this method sent the action method, we'd be hosed because we're possibly
    // changing the values below here.  However, Cocoa seems to send the action after this method is complete.
    // That's exactly what we want. :)
    if ( _sm_flags.isTrackingLoKnob )
    {
        // Limit to maximum of hi knob value (saved in _sm_saveValue).
        if ( self.doubleValue > _sm_hiValue )
            self.doubleValue = _sm_hiValue;

		// Only update the bound controller if this slider is continuous
		if ([self isContinuous])
		{
			[(SMDoubleSlider*)controlView updateBoundControllerLoValue:self.doubleValue];
		}
        _sm_loValue = self.doubleValue;
    }
    else if ( _sm_flags.isTrackingHiKnob )
    {
        // Limit to minimum of lo knob value.
        if ( self.doubleValue < _sm_loValue )
            self.doubleValue = _sm_loValue;
        
        // Only update the bound controller if this slider is continuous
        if ([self isContinuous])
        {
            [(SMDoubleSlider*)controlView updateBoundControllerHiValue:self.doubleValue];
        }
        _sm_hiValue = self.doubleValue;
    }
    else
    {
        // Limit to minimum of lo knob value.
//        if ( _value < _sm_loValue )
//            _value = _sm_loValue;
		
		// Only update the bound controller if this slider is continuous
		if ([self isContinuous])
		{
			[(SMDoubleSlider*)controlView updateBoundControllerHiValue:self.doubleValue];
		}
    }

    return result;
//    return [ super continueTracking:lastPoint at:currentPoint inView:controlView ];
}

- (void)stopTracking:(NSPoint)lastPoint at:(NSPoint)stopPoint inView:(NSView *)controlView mouseIsUp:(BOOL)flag
{
    if ( _sm_flags.mouseTrackingSwapped && _sm_flags.isTrackingLoKnob)
    {
        // If we were tracking the lo knob, stick the correct values into the correct places.
        _sm_loValue = self.doubleValue;
//        _value = _sm_saveValue;
        _sm_flags.mouseTrackingSwapped = NO;
        _sm_flags.isTrackingLoKnob = NO;
        [ controlView setNeedsDisplayInRect:[ self _sm_loKnobRect ] ];
		
		// Update the bound controller whether the slider is continuous or not
		[(SMDoubleSlider*)controlView updateBoundControllerLoValue:_sm_loValue];
    }
    else if (  _sm_flags.mouseTrackingSwapped && _sm_flags.isTrackingHiKnob )
    {
        _sm_hiValue = self.doubleValue;
//        _value = _sm_saveValue;
        _sm_flags.mouseTrackingSwapped = NO;
        _sm_flags.isTrackingHiKnob = NO;
        [ controlView setNeedsDisplayInRect:[ self _sm_hiKnobRect ] ];
        // Update the bound controller whether the slider is continuous or not
        [(SMDoubleSlider*)controlView updateBoundControllerHiValue:_sm_hiValue];
    }
    else
    {
		// Update the bound controller whether the slider is continuous or not
		[(SMDoubleSlider*)controlView updateBoundControllerHiValue:self.doubleValue];
    }

    [ super stopTracking:lastPoint at:stopPoint inView:controlView mouseIsUp:flag ];
}

#pragma mark -

- (void)setTrackingKnob:(NSPoint)point inView:(NSView *)controlView
{
    NSRect		loKnobRect;
    NSRect      hiKnobRect;
    
    // Determine if we're tracking the low knob or not.
    // Determine if we're tracking the high knob or not.
    loKnobRect = [ self _sm_loKnobRect ];
    hiKnobRect = [ self _sm_hiKnobRect ];
    [self setTrackingLoKnob:NSPointInRect(point, loKnobRect)];
    [self setTrackingHiKnob:NSPointInRect(point, hiKnobRect)];
//    
//    if ( [ self isVertical ] )
//    {
//        if ( [ controlView isFlipped ] )
//        {
//            [ self setTrackingLoKnob:( point.y > loKnobRect.origin.y ) ];
//        }
//        else
//        {
//            [ self setTrackingLoKnob:( point.y < loKnobRect.origin.y +
//                                      loKnobRect.size.height ) ];
//        }
//    }
//    else
//    {
//        [ self setTrackingLoKnob:( point.x < loKnobRect.origin.x + loKnobRect.size.width ) ];
//    }
    
    // Make sure that the user hasn't jammed both knobs up against the minimum value.
    if ( [ self trackingLoKnob ] && [ self trackingHiKnob ] )
    {
        if ( _sm_loValue > [ self minValue ] )
        {
            [ self setTrackingLoKnob:YES ];
            [ self setTrackingHiKnob:NO ];
        }
        else
        {
            [ self setTrackingLoKnob:NO ];
            [ self setTrackingHiKnob:YES ];
        }
    }
}

- (BOOL)trackingLoKnob
{
    return _sm_flags.isTrackingLoKnob;
}

- (void)setTrackingLoKnob:(BOOL)inValue
{
    if ( _sm_flags.isTrackingLoKnob != inValue )
    {
        _sm_flags.isTrackingLoKnob = inValue;
        [ (NSControl *)[ self controlView ] updateCell:self ];
    }
}

- (BOOL)trackingHiKnob
{
    return _sm_flags.isTrackingHiKnob;
}

- (void)setTrackingHiKnob:(BOOL)inValue
{
    if ( _sm_flags.isTrackingHiKnob != inValue )
    {
        _sm_flags.isTrackingHiKnob = inValue;
        [ (NSControl *)[ self controlView ] updateCell:self ];
    }
}

- (BOOL)lockedSliders
{
    return _sm_flags.lockedSliders;
}

- (void)setLockedSliders:(BOOL)inLocked
{
    if ( _sm_flags.lockedSliders != inLocked )
    {
        _sm_flags.lockedSliders = inLocked;

        if ( inLocked )
            [ self setDoubleLoValue:[ self doubleHiValue ] ];

        [ (NSControl *)[ self controlView ] updateCell:self ];
    }
}

#pragma mark -

//- (NSString *)stringValue
//{
//    if ( [ self trackingLoKnob ] )
//        return [ self stringLoValue ];
//    else if ( [ self trackingHiKnob ] )
//        return [ self stringHiValue];
//    else
//        return [];
//}
//
//- (id)objectValue
//{
//    if ( [ self trackingLoKnob ] )
//        return [ self objectLoValue ];
//    else
//        return [ self objectHiValue ];
//}
//
//- (int)intValue
//{
//    if ( [ self trackingLoKnob ] )
//        return [ self intLoValue ];
//    else
//        return [ self intHiValue ];
//}
//
//- (float)floatValue
//{
//    if ( [ self trackingLoKnob ] )
//        return [ self floatLoValue ];
//    else
//        return [ self floatHiValue ];
//}
//
//- (double)doubleValue
//{
//    if ( [ self trackingLoKnob ] )
//        return [ self doubleLoValue ];
//    else
//        return [ self doubleHiValue ];
//}
//
//- (void)setStringValue:(NSString *)aString
//{
//    if ( [ self trackingLoKnob ] )
//        [ self setStringLoValue:aString ];
//    else
//        [ self setStringHiValue:aString ];
//}

//- (void)setObjectValue:(id)obj
//{
//    if ( [ self trackingLoKnob ] )
//        [ self setObjectLoValue:obj ];
//    else
//        [ self setObjectHiValue:obj ];
//}
//
//- (void)setIntValue:(int)anInt
//{
//    if ( [ self trackingLoKnob ] )
//        [ self setIntLoValue:anInt ];
//    else
//        [ self setIntHiValue:anInt ];
//}

//- (void)setFloatValue:(float)aFloat
//{
//    if ( [ self trackingLoKnob ] )
//        [ self setFloatLoValue:aFloat ];
//    else
//        [ self setFloatHiValue:aFloat ];
//}
//
//- (void)setDoubleValue:(double)aDouble
//{
//    if ( [ self trackingLoKnob ] )
//        [ self setDoubleLoValue:aDouble ];
//    else
//        [ self setDoubleHiValue:aDouble ];
//}

#pragma mark -

- (double)doubleHiValue
{
//    NSLog( @"SMDSCell -doubleHiValue called %g (%d)", [ super doubleValue ],
//                _sm_flags.mouseTrackingSwapped );
//    if ( _sm_flags.mouseTrackingSwapped )
//        return _sm_saveValue;
//    else
//        return [ super doubleValue ];
    return  _sm_hiValue;
}

- (void)setDoubleHiValue:(double)aDouble
{
//    NSLog( @"SMDSCell -setDoubleHiValue:%g called (%d)", aDouble,
//                _sm_flags.mouseTrackingSwapped );

    // Limit to minimum of lo knob value.
    if ( aDouble < [ self doubleLoValue ] )
        aDouble = [ self doubleLoValue ];
    if ( aDouble > [ self maxValue ] )
        aDouble = [ self maxValue ];

//    if ( _sm_flags.mouseTrackingSwapped )
//    {
//        _sm_saveValue = aDouble;
//        [ (NSControl *)[ self controlView ] updateCell:self ];
//    }
//    else
//        [ super setDoubleValue:aDouble ];
    _sm_hiValue = aDouble;
}

- (id)objectHiValue
{
    return [ NSNumber numberWithDouble:[ self doubleHiValue ] ];
}

- (void)setObjectHiValue:(id)obj
{
    if ( [ obj respondsToSelector:@selector(doubleHiValue) ] )
        [ self setDoubleHiValue:[ obj doubleHiValue ] ];
    else if ( [ obj respondsToSelector:@selector(doubleValue) ] )
        [ self setDoubleHiValue:[ obj doubleValue ] ];
    else if ( [ obj respondsToSelector:@selector(floatValue) ] )
        [ self setDoubleHiValue:[ obj floatValue ] ];
    else if ( [ obj respondsToSelector:@selector(intValue) ] )
        [ self setDoubleHiValue:[ obj intValue ] ];
    else if ( [ obj respondsToSelector:@selector(stringValue) ] )
        [ self setStringHiValue:[ obj stringValue ] ];
	else
		[ self setDoubleHiValue:0.0 ];
}

- (NSString *)stringHiValue
{
    return [ NSString stringWithFormat:@"%g", [ self doubleHiValue ] ];
}

- (void)setStringHiValue:(NSString *)aString
{
    NSParameterAssert( nil != aString );

    [ self setDoubleHiValue:[ aString doubleValue ] ];
}

- (int)intHiValue
{
    return (int)[ self doubleHiValue ];
}

- (void)setIntHiValue:(int)anInt
{
    [ self setDoubleHiValue:anInt ];
}

- (float)floatHiValue
{
    return (float)[ self doubleHiValue ];
}

- (void)setFloatHiValue:(float)aFloat
{
    [ self setDoubleHiValue:aFloat ];
}

/*- (void)takeIntHiValueFrom:(id)sender
{
    [ super takeIntValueFrom:sender ];
}

- (void)takeFloatHiValueFrom:(id)sender
{
    [ super takeFloatValueFrom:sender ];
}

- (void)takeDoubleHiValueFrom:(id)sender
{
    [ super takeDoubleValueFrom:sender ];
}

- (void)takeStringHiValueFrom:(id)sender
{
    [ super takeStringValueFrom:sender ];
}

- (void)takeObjectHiValueFrom:(id)sender
{
    [ super takeObjectValueFrom:sender ];
}*/

#pragma mark -

#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
	- (void)setIntegerHiValue:(NSInteger)anInt;
	{
		[ self setDoubleHiValue:anInt ];
	}
	- (NSInteger)integerHiValue;
	{
		return (NSInteger)[ self doubleHiValue ];
	}
	- (void)setIntegerLoValue:(NSInteger)anInt;
	{
		[ self setDoubleLoValue:anInt ];
	}
	- (NSInteger)integerLoValue;
	{
		return (NSInteger)[ self doubleLoValue ];
	}
#endif

#pragma mark -

- (double)doubleLoValue
{
//    NSLog( @"SMDSCell -doubleLoValue called %g (%d)", _sm_loValue, _sm_flags.mouseTrackingSwapped );
//    if ( _sm_flags.mouseTrackingSwapped )
//        return _value;
//    else
        return _sm_loValue;
}

- (void)setDoubleLoValue:(double)aDouble
{
//    NSLog( @"SMDSCell -setDoubleLoValue:%g called (%d)", aDouble,
//                _sm_flags.mouseTrackingSwapped );
    if ( aDouble > [ self doubleHiValue ] )
        aDouble = [ self doubleHiValue ];
    if ( aDouble < [ self minValue ] )
        aDouble = [ self minValue ];

//    if ( _sm_flags.mouseTrackingSwapped )
//        [ super setDoubleValue:aDouble ];
//    else
//    {
//        _sm_loValue = aDouble;
//        [ (NSControl *)[ self controlView ] updateCell:self ];
//    }
    _sm_loValue = aDouble;
}

- (id)objectLoValue
{
    return [ NSNumber numberWithDouble:[ self doubleLoValue ] ];
}

- (void)setObjectLoValue:(id)obj
{
    if ( [ obj respondsToSelector:@selector(doubleLoValue) ] )
        [ self setDoubleLoValue:[ obj doubleLoValue ] ];
    else if ( [ obj respondsToSelector:@selector(doubleValue) ] )
        [ self setDoubleLoValue:[ obj doubleValue ] ];
    else if ( [ obj respondsToSelector:@selector(floatValue) ] )
        [ self setDoubleLoValue:[ obj floatValue ] ];
    else if ( [ obj respondsToSelector:@selector(intValue) ] )
        [ self setDoubleLoValue:[ obj intValue ] ];
    else if ( [ obj respondsToSelector:@selector(stringValue) ] )
        [ self setStringLoValue:[ obj stringValue ] ];
	else
        [ self setDoubleLoValue:0.0 ];
}

- (NSString *)stringLoValue
{
    return [ NSString stringWithFormat:@"%g", [ self doubleLoValue ] ];
}

- (void)setStringLoValue:(NSString *)aString
{
    NSParameterAssert( nil != aString );

    [ self setDoubleLoValue:[ aString doubleValue ] ];
}

- (int)intLoValue
{
    return (int)[ self doubleLoValue ];
}

- (void)setIntLoValue:(int)anInt
{
    [ self setDoubleLoValue:anInt ];
}

- (float)floatLoValue
{
    return (float)[ self doubleLoValue ];
}

- (void)setFloatLoValue:(float)aFloat
{
    [ self setDoubleLoValue:aFloat ];
}

/*- (void)takeIntLoValueFrom:(id)sender
{
    _sm_loValue = [ sender intValue ];
    [ (NSControl *)[ self controlView ] updateCell:self ];
}

- (void)takeFloatLoValueFrom:(id)sender
{
    _sm_loValue = [ sender floatValue ];
    [ (NSControl *)[ self controlView ] updateCell:self ];
}

- (void)takeDoubleLoValueFrom:(id)sender
{
    _sm_loValue = [ sender doubleValue ];
    [ (NSControl *)[ self controlView ] updateCell:self ];
}

- (void)takeStringLoValueFrom:(id)sender
{
    _sm_loValue = [ [ sender stringValue ] doubleValue ];
    [ (NSControl *)[ self controlView ] updateCell:self ];
}

- (void)takeObjectLoValueFrom:(id)sender
{
    [ self setObjectLoValue:[ sender objectValue ] ];
}*/

#pragma mark -

- (NSRect)_sm_loKnobRect
{
    NSRect	loKnobRect;
    double	saveValue;

    // Adjust the current value of the slider, get the rectangle, then reset the current value.
    saveValue = self.doubleValue;
    self.doubleValue = _sm_loValue;
    loKnobRect = [ self knobRectFlipped:[ [ self controlView ] isFlipped ] ];
    self.doubleValue = saveValue;
    
    loKnobRect.size.height *= 0.5;
    loKnobRect.origin.y += loKnobRect.size.height;
    loKnobRect.size.width *=0.5;
    
    return loKnobRect;
}

- (NSRect)_sm_hiKnobRect
{
    NSRect	hiKnobRect;
    double	saveValue;
    
    // Adjust the current value of the slider, get the rectangle, then reset the current value.
    saveValue = self.doubleValue;
    self.doubleValue = _sm_hiValue;
    hiKnobRect = [ self knobRectFlipped:[ [ self controlView ] isFlipped ] ];
    self.doubleValue = saveValue;
    hiKnobRect.size.height *= 0.5;
    hiKnobRect.origin.y += hiKnobRect.size.height;
    hiKnobRect.size.width *= 0.5;
    hiKnobRect.origin.x += hiKnobRect.size.width;
    return hiKnobRect;
}

- (NSRect)_sm_indicatorKnobRect
{
    NSRect	indicatorKnobRect;
    // Adjust the current value of the slider, get the rectangle, then reset the current value.
    indicatorKnobRect = [ self knobRectFlipped:[ [ self controlView ] isFlipped ] ];
    indicatorKnobRect.size.height *= 0.5;
    indicatorKnobRect.size.width *= 0.5;
    indicatorKnobRect.origin.x += indicatorKnobRect.size.width*0.5;
    
    return indicatorKnobRect;
}

@end
